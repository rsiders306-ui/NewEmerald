BeaconDex: Modern Emerald — playtest BPS patch

Apply BeaconDex-ModernEmerald-playtest.bps to the exact unmodified
Pokemon Modern Emerald 3.6 base ROM using a BPS-compatible patcher.
The base ROM and generated target ROM are not included in this ZIP.

Required base size: 33554432 bytes
Required base SHA256: bc7286dca750cf735480fece3ff68c7d86ecbf8391031b5ca2964da78fc945a1
Expected target SHA256: 222c0ed588905745292a2bc291a3f159d695a749647ae9e01e6055fa84250626
Patch SHA256: 55e6c52a0ce12b01c16cd6dcaae7c370b355af8e45f3ff7b9c24472a24b86f39

This is a development playtest build using the approved manifest stats and
draft graphics. It is not a final artwork or full gameplay validation claim.
The patch has been independently decoded, checksum-verified, and compared
byte-for-byte with the compiled target.
